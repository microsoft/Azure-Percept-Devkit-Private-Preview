#!/bin/bash

printf "\n****************************************************************\n"
printf "*                                                              *\n" 
printf "*                       DiagTool                               *\n"
printf "*     Azure Edge Devices (AED), Microsoft                      *\n"
printf "****************************************************************\n"

echo "Runnning DiagTool Diagnosis ..."

printf "\n****************************************************************\n" >diagtool_diagnosis.log
printf "*                                                              *\n" >>diagtool_diagnosis.log 
printf "*                       DiagTool                               *\n" >>diagtool_diagnosis.log
printf "*     Azure Edge Devices (AED), Microsoft                      *\n" >>diagtool_diagnosis.log
printf "****************************************************************\n">>diagtool_diagnosis.log
sleep 4

date | sed G >>diagtool_diagnosis.log
printf "******** Mariner OS Info**************\n" >>diagtool_diagnosis.log 
grep -v 'PRETTY' /etc/os-release | grep 'NAME' >>diagtool_diagnosis.log
grep "VERSION=" /etc/os-release >>diagtool_diagnosis.log
grep "BUILD_DATE=" /etc/os-subrelease >>diagtool_diagnosis.log
grep "VERSION_ID=" /etc/os-subrelease | sed G >>diagtool_diagnosis.log

printf "******** OS Sub-Release Info **************\n" >>diagtool_diagnosis.log
cat /etc/os-subrelease >> diagtool_diagnosis.log

#printf '\n***** ADU Version info *****\n' >>diagtool_diagnosis.log
#cat /etc/adu-version >>diagtool_diagnosis.log 

printf "\n******** UEFI **************\n" >>diagtool_diagnosis.log

out=$( ls /sys/class/gpio | grep gpio83)
if [[ -z "$out" && "$out" != "gpio83" ]]
then 
	echo 83 > /sys/class/gpio/export
fi 

out=$( ls /sys/class/gpio | grep gpio84)
if [[ -z "$out" && "$out" != "gpio84" ]]
then 
	echo 84 > /sys/class/gpio/export
fi 

out=$( ls /sys/class/gpio | grep gpio125)
if [[ -z "$out" && "$out" != "gpio125" ]]
then 
	echo 125 > /sys/class/gpio/export
fi 

out=$( ls /sys/class/gpio | grep gpio126)
if [[ -z "$out" && "$out" != "gpio126" ]]
then 
	echo 126 > /sys/class/gpio/export
fi 

out=$( ls /sys/class/gpio | grep gpio127)
if [[ -z "$out" && "$out" != "gpio127" ]]
then 
	echo 127 > /sys/class/gpio/export
fi 

	
PCBID0="$( cat /sys/class/gpio/gpio83/value )"
PCBID1="$( cat /sys/class/gpio/gpio84/value )"

GPIO125="$( cat /sys/class/gpio/gpio125/value )"
GPIO126="$( cat /sys/class/gpio/gpio126/value )"
GPIO127="$( cat /sys/class/gpio/gpio127/value )"

if ( [ $PCBID0 -eq 0 ] && [ $PCBID1 -eq 0 ] )
then
printf "PCB ID is 0\n">>diagtool_diagnosis.log
fi


if ( [ $GPIO125 -eq 1 ] && [ $GPIO126 -eq 1 ] && [ $GPIO127 -eq 1 ] )
then
printf "SKU ID is 7\n">>diagtool_diagnosis.log
fi

if ( [ $GPIO125 -eq 1 ] && [ $GPIO126 -eq 1 ] && [ $GPIO127 -eq 1 ] )
then 
	if ( [ $PCBID0 -eq 0 ] && [ $PCBID1 -eq 0 ] )
		then
			printf "Devkit = PE101, PCB Rev = R1.00\n" >>diagtool_diagnosis.log
	elif ( [ $PCBID0 -eq 0 ] && [ $PCBID1 -eq 1 ] )
		then 
			printf "Devkit = PE101, PCB Rev= R1.01\n">>diagtool_diagnosis.log
	elif ( [ $PCBID0 -eq 1 ] && [ $PCBID1 -eq 0 ] )
		then 
			printf "Devkit = PE101, PCB Rev = R1.02\n" >>diagtool_diagnosis.log
	else
		printf "SKU ID: 7, PCB ID: 3\n">>diagtool_diagnosis.log
		printf "Devkit = PE101, PCB Rev = Unidentified Rev\n" >>diagtool_diagnosis.log 
	fi
fi
		
if ( [ $GPIO125 -eq 0 ] && [ $GPIO126 -eq 0 ] && [ $GPIO127 -eq 0 ] )
then 
	if ( [ $PCBID0 -eq 0 ] && [ $PCBID1 -eq 0 ] )
		then
			printf "Devkit = PE100, PCB Rev = R1.00\n" >>diagtool_diagnosis.log
	elif ( [ $PCBID0 -eq 0 ] && [ $PCBID1 -eq 1 ] )
		then 
			printf "Devkit = PE100, PCB Rev= R1.01\n" >>diagtool_diagnosis.log
	elif ( [ $PCBID0 -eq 1 ] && [ $PCBID1 -eq 0 ] )
		then 
			printf "Devkit = PE100, PCB Rev = R1.02\n" >>diagtool_diagnosis.log
	else
		printf "SKU ID: 0, PCB ID: 3\n">>diagtool_diagnosis.log
		printf "Devkit = PE100, PCB Rev = Unidentified Rev\n" >>diagtool_diagnosis.log 
	fi
fi

healthid=$(azure-device-health-id)
printf "\nAzure-Device-Health-ID: $healthid\n">>diagtool_diagnosis.log 	
	
echo 83 > /sys/class/gpio/unexport
echo 84 > /sys/class/gpio/unexport
echo 125 > /sys/class/gpio/unexport
echo 126 > /sys/class/gpio/unexport
echo 127 > /sys/class/gpio/unexport

printf "\n******** SoM **************\n" >>diagtool_diagnosis.log

#flag to check if som is connected
foundsomcontroller=0

AUTH_EYE_CNT=$(lsusb | grep -c -i '045e:066f') 
if [ $AUTH_EYE_CNT -gt 0 ]
then 
	printf "$AUTH_EYE_CNT Azure Eye SoM(s) found.\n">>diagtool_diagnosis.log
	serialnum=$(lsusb -d 045e:066f -v | grep 'iSerial'| cut -b 29-)
	printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
	
	securityfw=$( lsusb -d 045e:066f -v | grep bcdDevice | cut -b 12- )
	if [ $securityfw = "0.08" ]
	then
		printf "Security Firmware version: 0.08 - Private Preview version \n">>diagtool_diagnosis.log
	else
		if [ $securityfw = "2.00" ]
		then 
			printf "Security Firmware version: 2.00 - Old Bypass version\n">>diagtool_diagnosis.log
		else
			printf "Security Firmware version: $securityfw\n">>diagtool_diagnosis.log
		fi
	fi
	
	#set foundsomcontroller flag 
	foundsomcontroller=1 
fi


Ear_CNT=$(lsusb | grep -c -i '045e:0673')
if [ $Ear_CNT -gt 0 ]
then
	printf "\n$Ear_CNT Azure Ear SoM(s) found.\n" >>diagtool_diagnosis.log
	ear_serialnum=$(lsusb -d 045e:0673 -v | grep 'iSerial'| cut -b 29-)
	printf "Serial Number: $ear_serialnum\n" >>diagtool_diagnosis.log
	
	ear_securityfw=$( lsusb -d 045e:0673 -v | grep bcdDevice | cut -b 12- )
	if [ $ear_securityfw = "0.08" ]
	then
		printf "Security Firmware version: 0.08 - Private Preview version \n">>diagtool_diagnosis.log
	else
		if [ $ear_securityfw = "2.00" ]
		then 
			printf "Security Firmware version: 2.00 - One way Authentication version\n">>diagtool_diagnosis.log
		else
			printf "Security Firmware version:  $ear_securityfw\n">>diagtool_diagnosis.log
		fi
	fi
	
	#Get codec firmware version from speech module
	
	earcontainer=$(docker ps | grep "azureearspeechclientmodule")
	if [ -z "$earcontainer" ]
	then 
	printf "azurespeechclientmodule is not running. No codec firmware running. "
	else 
		docker logs azureearspeechclientmodule > diag_ear.log 
		codec_ver=$(cat diag_ear.log | grep -A 7 "Azure Ear Microphone "| grep "bcdDevice"| tail -1 | cut -b 15-)
		printf "Codec Firmware version: $codec_ver\n">>diagtool_diagnosis.log
		rm diag_ear.log
	fi 
	
	#set foundsomcontroller flag 
	foundsomcontroller=1
	
fi


DEFAULT_MYRIAD_CNT=$(lsusb | grep -c -i '03e7:2485')
DEF_MYRIAD_CNT2=$(lsusb | grep -c -i '03e7:f63b')
AZ_MYRIAD_CNT=$(lsusb | grep -c -i '045e:0670')
MIC_ARRAY_CNT=$(lsusb | grep -c -i '045e:0671')

BYPASS_STM_CNT=$(lsusb | grep -c -i '0483:5740')

# if two STM32 PID/VID, then ask them to remove one SoM. 
if [ $BYPASS_STM_CNT -gt 1 ]
then 
	printf "\nThere are $BYPASS_STM_CNT Unidentified STM32 chips connected to the Carrier board. Please unplug all SoMs and plug one SoM device at a time. Then re-run the DiagTool to find further info of each SoM\n" >>diagtool_diagnosis.log
	#set foundsomcontroller flag
	foundsomcontroller=1
fi 

# if only one unknown STM32 connected, then find the SoM details based on whether Intel chip is enumerated or the Mic array is enumerated:  
if [ $BYPASS_STM_CNT -eq 1 ]
then 
	#set foundsomcontroller flag 
	foundsomcontroller=1 
	printf "\n">>diagtool_diagnosis.log
	
	#Check if you can see Intel chip along with the unknown STM32 chip
	if [ $DEFAULT_MYRIAD_CNT -eq 1 -o $DEF_MYRIAD_CNT2 -eq 1 -o $AZ_MYRIAD_CNT -eq 1 ]
	then
		securityfw=$( lsusb -d 0483:5740 -v | grep bcdDevice | cut -b 12- )
		if [ $securityfw = "0.08" ]
		then
			printf "$BYPASS_STM_CNT Azure Eye SoM(s) found but incorrect SoM controller VID/PID.\n" >>diagtool_diagnosis.log
			serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
			printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
			printf "Security Firmware version: 0.08 - Private Preview version \n" >>diagtool_diagnosis.log
		else
			if [ $securityfw = "2.00" ]
			then
				printf "$BYPASS_STM_CNT Azure Eye SoM(s) found but incorrect SoM controller VID/PID.\n" >>diagtool_diagnosis.log
				serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
				printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
				printf "Security Firmware version: 2.00 - old Bypass version\n">>diagtool_diagnosis.log
			else
				printf "$BYPASS_STM_CNT Unknown STM32 MCU(s) and Intel MyriadX found.\n" >>diagtool_diagnosis.log
				serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
				printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
				printf "Security Firmware version: $securityfw\n" >>diagtool_diagnosis.log
			fi
		fi
		
	#check if you see MIC array along with the unknown STM32 chip
	elif [ $MIC_ARRAY_CNT -eq 1 ]
	then
		ear_securityfw=$( lsusb -d 0483:5740 -v | grep bcdDevice | cut -b 12- )
		if [ $ear_securityfw = "0.08" ]
		then 
			printf "$BYPASS_STM_CNT Azure Ear SoM(s) found but incorrect SoM controller VID/PID.\n" >>diagtool_diagnosis.log
			serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
			printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
			printf "Security Firmware version: 0.08 - Private Preview version \n" >>diagtool_diagnosis.log
			
			#Get codec firmware version from speech module
			earcontainer=$(docker ps | grep "azureearspeechclientmodule")
			if [ -z "$earcontainer" ]
			then 
			printf "azurespeechclientmodule is not running. No codec firmware running. "
			else 
				docker logs azureearspeechclientmodule > diag_ear.log 
				codec_ver=$(cat diag_ear.log | grep -A 7 "Azure Ear Microphone "| grep "bcdDevice"| tail -1 | cut -b 15-)
				printf "Codec Firmware version: $codec_ver\n">>diagtool_diagnosis.log
				rm diag_ear.log
			fi
		else
			if [ $securityfw = "2.00" ]
			then
				printf "$BYPASS_STM_CNT Azure Ear SoM(s) found but incorrect SoM controller VID/PID.\n" >>diagtool_diagnosis.log
				serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
				printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
				printf "Security Firmware version: 2.00 - One way Authentication version\n">>diagtool_diagnosis.log
				#Get codec firmware version from speech module
				earcontainer=$(docker ps | grep "azureearspeechclientmodule")
				if [ -z "$earcontainer" ]
				then 
				printf "azurespeechclientmodule is not running. No codec firmware running. "
				else 
					docker logs azureearspeechclientmodule > diag_ear.log 
					codec_ver=$(cat diag_ear.log | grep -A 7 "Azure Ear Microphone "| grep "bcdDevice"| tail -1 | cut -b 15-)
					printf "Codec Firmware version: $codec_ver\n">>diagtool_diagnosis.log
					rm diag_ear.log
				fi
			else
				printf "$BYPASS_STM_CNT Unknown STM32 MCU(s) and MIC ARRAY found.\n" >>diagtool_diagnosis.log
				serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
				printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
				printf "Security Firmware version: $securityfw\n" >>diagtool_diagnosis.log
				
				#Get codec firmware version from speech module
				earcontainer=$(docker ps | grep "azureearspeechclientmodule")
				if [ -z "$earcontainer" ]
				then 
				printf "azurespeechclientmodule is not running. No codec firmware running. "
				else 
					docker logs azureearspeechclientmodule > diag_ear.log 
					codec_ver=$(cat diag_ear.log | grep -A 7 "Azure Ear Microphone "| grep "bcdDevice"| tail -1 | cut -b 15-)
					printf "Codec Firmware version: $codec_ver\n">>diagtool_diagnosis.log
					rm diag_ear.log
				fi
			fi
		fi
	
	#when you can see only a unknown STM32 and no other component
	else 
		printf "Unknown STM32 MCU found.\n">>diagtool_diagnosis.log 
		serialnum=$(lsusb -d 0483:5740 -v | grep 'iSerial'| cut -b 29-)
		printf "Serial Number: $serialnum\n" >>diagtool_diagnosis.log
		securityfw=$( lsusb -d 0483:5740 -v | grep bcdDevice | cut -b 12- )
		printf "Security Firmware version: $securityfw\n" >>diagtool_diagnosis.log
	fi 
fi

if [ $foundsomcontroller == 0 ]
then 
printf " No SoM controllers found.\n">>diagtool_diagnosis.log 
fi

# list the myriad and mic devices, if found. 

printf "\n******** List of enumerated MyriadX & Mic arrays *********\n">>diagtool_diagnosis.log
if [ $DEFAULT_MYRIAD_CNT -gt 0 ]
then 
	printf "$DEFAULT_MYRIAD_CNT Unknown Intel MyriadX Device found.\n" >>diagtool_diagnosis.log
fi

DEF_MYRIAD_CNT2=$(lsusb | grep -c -i '03e7:f63b')
if [ $DEF_MYRIAD_CNT2 -gt 0 ]
then 
	printf "$DEF_MYRIAD_CNT2 Unknown Intel MyriadX Device found.\n">>diagtool_diagnosis.log
fi

AZ_MYRIAD_CNT=$(lsusb | grep -c -i '045e:0670')
if [ $AZ_MYRIAD_CNT -gt 0 ]
then
	printf "$AZ_MYRIAD_CNT Microsoft verified MyriadX inside Azure Eye SoM Found\n" >>diagtool_diagnosis.log
fi

MIC_ARRAY_CNT=$(lsusb | grep -c -i '045e:0671')
if [ $MIC_ARRAY_CNT -gt 0 ]
then 
	printf "$MIC_ARRAY_CNT  Microsoft verified Mic Array inside Azure Ear SoM Found.\n" >>diagtool_diagnosis.log
fi

echo "Diagnosis is ready."
echo "To open the diagnosis:"
echo "	cat diagtool_diagnosis.log"